# image_processing

Description. 
The package image_processing is used to:
	Processing:
		- Histrogram matching
		- Strucutural similarity
		- Resize images
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histrogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```



## Author
Caua Lira

## License
[MIT](https://choosealicense.com/licenses/mit/)